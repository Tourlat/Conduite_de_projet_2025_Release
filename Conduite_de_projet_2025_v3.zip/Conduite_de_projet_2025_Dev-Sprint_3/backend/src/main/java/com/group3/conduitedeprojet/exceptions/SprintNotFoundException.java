package com.group3.conduitedeprojet.exceptions;

public class SprintNotFoundException extends RuntimeException {
  public SprintNotFoundException(String message) {
    super(message);
  }
}
