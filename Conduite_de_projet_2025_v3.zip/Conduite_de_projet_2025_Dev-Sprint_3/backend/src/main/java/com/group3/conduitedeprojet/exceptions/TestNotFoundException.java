package com.group3.conduitedeprojet.exceptions;

public class TestNotFoundException extends RuntimeException {
  public TestNotFoundException(String message) {
    super(message);
  }
}
