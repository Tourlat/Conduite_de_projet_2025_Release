package com.group3.conduitedeprojet.dto;

import lombok.Data;

@Data
public class UpdateProjectRequest {
  private String name;
  private String description;
}
