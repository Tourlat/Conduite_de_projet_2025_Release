package com.group3.conduitedeprojet.dto;

import lombok.Data;

@Data
public class UpdateTestRequest {
  private String programCode;
  private String testCode;
}
