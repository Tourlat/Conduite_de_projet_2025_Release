package com.group3.conduitedeprojet.dto;

import lombok.Data;

@Data
public class CreateTestRequest {
  private String programCode;
  private String testCode;
}
