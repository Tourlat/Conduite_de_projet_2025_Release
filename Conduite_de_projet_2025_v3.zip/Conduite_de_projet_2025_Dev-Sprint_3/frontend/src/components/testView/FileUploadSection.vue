<template>
  <div class="upload-section">
    <div class="upload-controls">
      <div class="upload-group">
        <label for="code-file-upload" class="upload-label">
          Charger un fichier de code (.js, .txt)
        </label>
        <input
          id="code-file-upload"
          class="file-input"
          type="file"
          accept=".js,.txt,.mjs"
          @change="handleCodeFileUpload"
        />
      </div>
      <div class="upload-group">
        <label for="test-file-upload" class="upload-label">
          Charger un fichier de tests (.js, .txt)
        </label>
        <input
          id="test-file-upload"
          class="file-input"
          type="file"
          accept=".js,.txt,.mjs"
          @change="handleTestFileUpload"
        />
      </div>
      <button class="btn-download" @click="$emit('download')">
        Télécharger les fichiers
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
const emit = defineEmits<{
  uploadCode: [content: string]
  uploadTests: [content: string]
  download: []
}>()

/**
 * Handle file upload for code or tests.
 * @param event the file input change event
 * @param isCode true if uploading code, false for tests
 */
const handleFileUpload = async (event: Event, isCode: boolean) => {
  const target = event.target as HTMLInputElement
  const file = target.files?.[0]
  
  if (file) {
    try {
      const content = await file.text()
      if (isCode) {
        emit('uploadCode', content)
      } else {
        emit('uploadTests', content)
      }
    } catch {
      alert('Erreur lors de la lecture du fichier')
    }
    // Réinitialiser l'input pour permettre de recharger le même fichier
    target.value = ''
  }
}

/**
 * Handle code file upload.
 * @param event the file input change event
 */
const handleCodeFileUpload = (event: Event) => {
  handleFileUpload(event, true)
}

/**
 * Handle test file upload.
 * @param event the file input change event
 */
const handleTestFileUpload = (event: Event) => {
  handleFileUpload(event, false)
}
</script>

<style scoped>
.upload-section {
  background: var(--terminal-hover);
  border: 1px solid var(--terminal-border);
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1.5rem;
}

.upload-controls {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
  align-items: center;
}

.upload-group {
  flex: 1;
  min-width: 250px;
}

.upload-label {
  display: block;
  padding: 0.6rem 1rem;
  background: var(--terminal-bg);
  color: var(--terminal-fg);
  border: 1px solid var(--terminal-border);
  border-radius: 4px;
  cursor: pointer;
  text-align: center;
  transition: all 0.2s;
  font-size: 0.9rem;
  font-weight: 500;
}

.upload-label:hover {
  background: var(--terminal-hover);
  border-color: var(--terminal-accent);
  color: var(--terminal-accent);
}

.file-input {
  display: none;
}

.btn-download {
  padding: 0.6rem 1.5rem;
  background: var(--terminal-accent);
  color: white;
  border: 1px solid var(--terminal-accent);
  border-radius: 4px;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.9rem;
  transition: all 0.2s;
  white-space: nowrap;
}

.btn-download:hover {
  background: var(--terminal-accent-dark);
  border-color: var(--terminal-accent-dark);
  transform: translateY(-2px);
}
</style>
